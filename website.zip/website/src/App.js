import React from 'react';
// import ExpenseItem from './components/ExpenseItem';
import Expenses from './components/Expenses';

const App = () => {
  const expenses = [
    {
      id:'e1',
      title: 'Car Insurances',
      amount: 1500,
      date: new Date(2021, 12, 22),
    },
    {
      id:'e2',
      title: 'Bike Insurances',
      amount: 1000,
      date: new Date(2021, 2, 12),
    },
    {
      id:'e3',
      title: 'Truck Insurances',
      amount: 2500,
      date: new Date(2021, 1, 14),
    },
    {
      id:'e4',
      title: 'Bus Insurances',
      amount: 3500,
      date: new Date(2022, 12, 22),
    },
    {
      id:'e5',
      title: 'Van Insurances',
      amount: 4500,
      date: new Date(2022, 11, 21),
    },
  ];

  return (
    <div>
     <Expenses items={expenses}/> 
    </div>
  );
}

export default App;
